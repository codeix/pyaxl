Changelog
=========

1.0-dev (2015-08-03)
--------------------

- Initial [Samuel Riolo]

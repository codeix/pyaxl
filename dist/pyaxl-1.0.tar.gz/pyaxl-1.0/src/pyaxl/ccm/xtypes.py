from pyaxl.ccm.abstracts import AbstractXType
from pyaxl.ccm.abstracts import AbstractXTypeListItem


class XPhoneLine(AbstractXType):
    pass


class XCallForwardAll(AbstractXType):
    pass


class XCallForwardAlternateParty(AbstractXType):
    pass


class XCallForwardBusy(AbstractXType):
    pass


class XCallForwardBusyInt(AbstractXType):
    pass


class XCallForwardNoAnswer(AbstractXType):
    pass


class XCallForwardNoAnswerInt(AbstractXType):
    pass


class XCallForwardNoCoverage(AbstractXType):
    pass


class XCallForwardNoCoverageInt(AbstractXType):
    pass


class XCallForwardNotRegistered(AbstractXType):
    pass


class XCallForwardNotRegisteredInt(AbstractXType):
    pass


class XCallForwardOnFailure(AbstractXType):
    pass


class XLineAppearanceAssociationForPresence(AbstractXType):
    pass


class XLineAssociation(AbstractXType):
    pass
